﻿Documenta¸c˜ao rede invent´ario

Davi Bezerra November 2025

1 Inic´ıo

Este laborat´orio ´e uma pr´atica simplificada de um ambiente de redes com virtual box. O intuito ´e implementar a configura¸c˜ao de Failover de links WAN utilizando Netwatch.

Links de referˆencia:

1. https://mkcontroller.com/mikrotik-failover-complete-guide-for-high-availability- and-business-continuity/
1. https://ravel.com.br/blog/mikrotik-configuracao-de-failover-via-netwatch/ Equipamentos iniciais:
1. RouterOS vers˜ao Cloud Hosted Router VDI Image
1. Duas interfaces NAT
1. Duas interfaces Host-Only

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.001.png)

Figure 1: Cen´ario simplificado

1. Configura¸c˜ao inicial

Resumidamente, temos que ativar primeiro as interfaces no virtual box. Em ferramentas, criamos duas interfaces Host-only (n˜ao ser˜ao utilizadas no projeto, apenas para manter no MikroTik para uso posterior) e inserimos 4 interfaces na VM.

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.002.png)

Figure 2: Interfaces virtualbox

No MikroTik, podemos ver a lista de interfaces com o comando interface print, que vai gerar a lista

[admin@MikroTik] > interface print

Flags: R - RUNNING

Columns: NAME, TYPE, ACTUAL-MTU, MAC-ADDRESS

- NAME TYPE ACTUAL-MTU MAC-ADDRESS 0 R ether4 ether 1500 08:00:27:EA:82:B1

  1 R ether5 ether 1500 08:00:27:74:9A:C5 2 R ether6 ether 1500 08:00:27:E6:22:04 3 R ether7 ether 1500 08:00:27:C6:C9:21 4 R lo loopback 65536 00:00:00:00:00:00

  As duas primeiras interfaces s˜ao as interfaces NAT. Em seguida, ativamos o DHCP das interfaces NAT com os comandos:

  ip dhcp-client add interface=ether4 disabled=no ip dhcp-client add interface=ether5 disabled=no

(OPCIONAL)

Ativamos agora endere¸cos est´aticos para as interfaces Host-only:

ip address add address=192.168.56.5/24 interface=ether6 ip address add address=192.168.57.5/24 interface=ether7

Para ver as interfaces e IPs registrados, usamos o comando ip address

print:

[admin@MikroTik] > ip address print

Flags: I - INVALID; D - DYNAMIC

Columns: ADDRESS, NETWORK, INTERFACE

- ADDRESS NETWORK INTERFACE 0 I 192.168.56.10/24 192.168.56.0 \*3
1  192.168.56.5/24 192.168.56.0 ether6
1  192.168.57.5/24 192.168.57.0 ether7
1  D 10.0.3.15/24 10.0.3.0 ether5
1  D 10.0.2.15/24 10.0.2.0 ether4
2. Cria¸c˜ao de rotas WAN

Na interface web do MikroTik, acessamos a aba IP - DHCP Client e desativamos as op¸c˜oes ativas. O MikroTik n˜ao tem mais acesso a internet nesse momento. Em rotas, temos que definir agora a principal e a secund´aria. Em IP - Rotas, clicamos em Novo e inserimos essas informa¸c˜oes:

Definimos e comentamos a rota principal, que estar´a ativa na maior parte do tempo, e a rota secund´aria, que assume quando a principal cai.

3. Monitoramento e Failover

Para criar o failover, temos que habilitar o monitoramento com Netwatch. Primeiro, criamos uma rota de monitoramento WAN que usa o mesmo gate- way da rota principal. Usamos o endere¸co IP de um servidor raiz da internet (192.5.5.241).

Essa rota ser´a usada pelo netwatch para verificar a integridade do gateway. Em Tools - Netwatch, criamos essa configura¸c˜ao:

Basicamente, o netwatch realiza a a¸c˜ao de verificar a cada 30 segundos se h´a alcance para esse IP de destino atrav´es da rota definida. Se n˜ao houver, ele

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.003.jpeg)

Figure 3: Rota principal

desativa o gateway principal. O ato de desativar o gateway automaticamente repassa o tr´afego para o secund´ario, pois a distancia est´a definida como 1 para o principal e 2 para o secund´ario.

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.004.jpeg)

Figure 4: Rota secund´aria

4. Teste de conectividade

Por terminal, podemos dar um ping para a internet publica´ com o comando ping 8.8.8.8:

Para fazer o teste de failover, deixamos o ping sem parar e no virtual box, na configura¸c˜ao de interface do gateway, habilitamos a op¸c˜ao cabo desconectado:

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.005.jpeg)

Figure 5: Rota de monitoramento

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.006.jpeg)

Figure 6: Monitoramento com Netwatch

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.007.png)

Figure 7: Ping inicial

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.008.jpeg)

Figure 8: Cabo desconectado

Ao desconectar o cabo, vemos que em um dos pings recebemos timeout, mas logo em seguida o acesso ao ip ´e reestabelecido, mostrando que o monitoramento e ativa¸c˜ao da rota secund´aria funciona:

![](Aspose.Words.5cfb322a-3e15-4749-9652-a5cc2635a863.009.png)

Figure 9: Reconex˜ao
8
